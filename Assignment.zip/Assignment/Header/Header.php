<?php
//session_start();
?>

<!DOCTYPE html>
<html>
<head>
<style>
ul {
  list-style-type: none;
  margin: 0;
  margin-bottom: 3px;
  padding: 0;
  overflow: hidden;
  background-color: #333;

  
}

li {
  float: left;
  padding: 10px;
  font-size: 30px;
  margin-top: 0px;
  
}

li a {
  display: block;
  color: white;
  text-align: center;
  padding: 14px 16px;
  text-decoration: none;
}

.active {
  background-color: #04AA6D;
}
li a, .dropbtn {
  display: inline-block;
  color: white;
  text-align: center;
  padding: 14px 16px;
  text-decoration: none;
}

li a:hover, .dropdown:hover .dropbtn {
  background-color:darkolivegreen;
}

li.dropdown {
  display: inline-block;
}

.dropdown-content {
  display: none;
  position: fixed;
  background-color: #f9f9f9;
  min-width: 160px;
  box-shadow: 0px 8px 16px 0px rgba(0,0,0,0.2);
  
}

.dropdown-content a {
  color: black;
  padding: 12px 16px;
  text-decoration: none;
  display: block;
  text-align: left;
  background-color: burlywood;
 
  
}

.dropdown-content a:hover {background-color: #f1f1f1;}

.dropdown:hover .dropdown-content {
  display: block;
}
.headr{
  width: 100%;
  margin: 0%;
  position: fixed;
  top: 0%;
  margin-bottom: 50px;
  z-index: 99;
}
#myid1{
            margin-bottom: 0px;
            height: 70px;
            font-size: 50px;
            color: green;
            background-color: yellowgreen;
            border:10px solid blue ;
            font-weight: bold;
        }
</style>
</head>
<body>
  <div class="headr">
  <marquee id="myid1"  width="100%"  
         direction="left" scrollamount="20">COURSE MANAGEMENT SYSTEM FOR SOFTWARE ENGINEERING</marquee>
<ul>
  <li><a href="index.php"  class="active">Home</a></li>
  <li class="dropdown">
    <a href="" class="dropbtn">Registration</a>
    <div class="dropdown-content">
      <a href="Student.php">Student Registration</a>
      <a href="Teacher.php">Teacher Registration</a>
      <a href="Courses.php">Course Registration</a>
    </div>
  </li>

  <li><a href="About.php">About</a></li>
  <li><a href="Contact.php">Contact us</a></li>
  <li style="float:right">
  
              <!-- <span ><?php echo $_SESSION['user']; ?></span> -->
 
          
          <a href="../security/login.php">Logout</a></li>
</ul>
  </div>

</body>
</html>


