<!DOCTYPE html>
<html>
    <head>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <title></title>
        <meta name="description" content="">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <link rel="stylesheet" href="">
        <style>
        body {
            font-family: Arial, Helvetica, sans-serif;
            margin: 0;
        }

        html 
        {
            box-sizing: border-box;
        }

        *,
        *:before,
        *:after {
            box-sizing: inherit;
        }

        .columm {
            float: left;
            width: 33.3%;
            margin-bottom: 16px;
            padding: 0 8px;
        }
        .about {
            margin-left: 20px;
            text-decoration: none;
        }
        .card {
            box-shadow: 0 4px 8px 0 rgba(0, 0, 0, 0.2);
            margin: 8px;
        }

        .about-section {
            padding: 50px;
            text-align: center;
            background-color: #474e5d;
            color: white;
            font-size: 25px;
        }

        .container
       {
            padding: 0 16px;
        }

        .container::after,
        .ro::after {
            content: "";
            clear: both;
            display: table;
        }

        .title {
            color: grey;
        }

        .button {
            border: none;
            outline: 0;
            display: inline-block;
            padding: 8px;
            color: white;
            background-color: #000;
            text-align: center;
            cursor: pointer;
            width: 100%;
        }

        .button:hover {
            background-color: #555;
        }

        @media screen and (max-width: 650px) {
            .columm,.contact {
                width: 100%;
                display: block;
            }
        }
        img{
            width :90px !important;
            height: 90px !important;
            
        }
                .ro{
                margin-top: 50%;
      background-color:darkgray;
    
                  }
</style>
    </head>
    <body>
    <div class="contact" style="max-height: 200px;">
        <div class="rowf">
           <div class="columm">
            <p>About This Website</p>
            <div class="about">
                        <strong><p><a href="#" style="text-decoration: none">HOME</a></p></strong>
                        <strong><p><a href="#" style="text-decoration: none">Register</a></p></strong>
                        <strong><p><a href="#" style="text-decoration: none">Info</a></p></strong>
            </div>
           </div>
          <div class="ro">
           <div class="columm">
                <p>Contact Us</p>
                <div>
                  <ul> 
                    <li> 
                    <div>
                        <p>  Phone</p>
                        <ol>
                        <li><a href="tel:+251923233128">0923233128</a></li>
                        <li><a href="tel:+251923146361">0923146361</a></li>
                        <li><a href="tel:+251952614818">0952614852</a></li>
                       
                        </ol>
                    </div>
                   </li>
                   <li>
                    <div>
                        <p>  Email</p>
                        <ol>
                            <li><a href="mailto:yilkalderseh@gmail.com">yilkalderseh@gmail.com</a></li>
                            <li><a href="mailto:asmamawtemesgen16@gmail.com">asmamawtemesgen16@gmail.com</a></li>
                        
                       </ol>
                    </div>
                   </li>
                   <li>
                    <div>
                        <p>  Telegram</p>
                        <ol>
                            <li><a href="http://t.me/@lkalyi">http://t.me/@lkalyi</a></li>
                            <li><a href="http://t.me/@lkalyi">http://t.me/@lkalyi</a></li>
                            
                        </ol>
                    </div>
                    </li>
                </ul>
                </div>
           </div>
     <div class="ro">
           <div class="columm">
            <p>Leave Comment</p>
            <div class="about">
                        <p><a href="muFooter.html" style="text-decoration: none">About Us</a></p>
            </div>
           </div> 
   </div>  
    </body>
</html>

