<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <style>
  body {font-family: Arial, Helvetica, sans-serif;}
* {box-sizing: border-box}

/* Full-width input fields */
input[type=text], input[type=password] {
  width: 100%;
  padding: 15px;
  margin: 5px 0 22px 0;
  display: inline-block;
  border: none;
  background: #f1f1f1;
}

input[type=text]:focus, input[type=password]:focus {
  background-color: #ddd;
  outline: none;
}

hr {
  border: 1px solid #f1f1f1;
  margin-bottom: 25px;
}

/* Set a style for all buttons */
button {
  background-color: #04AA6D;
  color: white;
  padding: 14px 20px;
  margin: 8px 0;
  border: none;
  cursor: pointer;
  width: 100%;
  opacity: 0.9;
}

button:hover {
  opacity:1;
}
.mydiv a{
  background-color: white;
  padding: 10px;
  margin: 15px;
}

/* Extra styles for the cancel button */


/* Float cancel and signup buttons and add an equal width */
 .signup {
  float: left;
  width: 30%;
  height: 50px;
  font-size: 20px;
  align-items: center;
  margin-left: 300px;
  background-color: gray;
  color: white;
}

.mylog {
  padding: 56px;
  margin-left: 600px;
  text-decoration: none;
  color: white;
  font-size: 25px;
  color: white;
}
.mylog a{
  color: white;
}

/* Clear floats */

/* Change styles  signup button on extra small screens */
@media screen and (max-width: 300px) {
 
}
.mydiv{
  margin: 90px;
  /* border: 10px solid green; */
 position: relative;
 text-align: left;
 background-color: darkgrey;
 color: whitesmoke;
 font-size: 25px;
 padding: 50px;
 width: 30%;
 height: 40%;
 margin-left: 500px;
/* border-radius: 300px; */
}

h1,h4{
  text-align: center;
}
</style>
<script>
  function validateForm() {
  let x = document.forms["myForm"]["name"].value;
  let l = document.forms["myForm"]["lname"].value;
  let y = document.forms["myForm"]["email"].value;
  let z = document.forms["myForm"]["password"].value;
  let p = document.forms["myForm"]["p_repeat"].value;
  let r = document.forms["myForm"]["role"].value;
  
  if (x == ""|| y== "" || z == "" || p==""||l==""||r=="") {
    alert("please fill out all forms");
  return false;
   }
   if(z!=p){
    alert("password is not matched");
    return false;
   }

}
</script>
</head>
<body>
    <form action="" method="POST" onsubmit="return validateForm()" name="myForm"><br><br>
   <!-- Name <input type="text" name="name"><br><br>
    <input type="text" name="lname"><br><br>
    <input type="text" name="email"><br><br>
    <input type="text" name="password"><br><br>
    <input type="text" name="role"><br><br>
    <input type="submit" name="save" value="sign up"> -->

    <div class="mydiv">
<h1>Sign Up</h1><br>
<h4>Please fill in this form to create an account.</h4>

   
    <hr>
    
Name <input type="text" placeholder="Enter your name" name="name" style="margin-left :70px;height:30px;width:60%;margin-top:10px;font-size: 23px;" ><br><br>
Last Name <input type="text" placeholder="Enter your name" name="lname" style="margin-left: 20px;height:30px;width:60%;margin-top:10px;font-size: 23px;"><br><br>
Email <input type="text" placeholder="Enter Email" name="email" style="margin-left: 80px;height:30px;width:60%;margin-top:10px;font-size: 23px;"><br><br>
password <input type="password" placeholder="Enter Password" name="password" style="margin-left: 40px;height:30px;width:60%;margin-top:10px;font-size: 23px;"><br><br>
Repeat <input type="password" placeholder="Repeat Password" name="p_repeat" style="margin-left: 60px;height:30px;width:60%;margin-top:10px;font-size: 23px;"> <br><br>
Role<input name="role" id="r1" class="roles" placeholder="role" style="margin-left: 90px;height:30px;width:60%;margin-top:10px;font-size: 23px;">
          <br><br><br><br>
    <input type="submit" value="sign up" class="signup" name="save" >
  <p> I have an account!<p><a href="login.php" >login</a> </p>
    
</div>

<form> 
  </div>
    </form>
    
</body>
</html>
<?php
include('../database/db.php');
if ($_SERVER["REQUEST_METHOD"] == "POST"){
    if (isset($_POST['save'])) {

    $name = test_input($_POST["name"]);
    $lname = test_input($_POST["lname"]);
    $email = test_input($_POST["email"]);
    $password = test_input($_POST["password"]);
    $cpassword = test_input($_POST["p_repeat"]);
    $role = test_input($_POST["role"]);
  
    // Validate e-mail
  if (!filter_var($email, FILTER_VALIDATE_EMAIL) === false) {
     // echo("$email is a valid email address");
   
     if ($password==$cpassword) {
     
      if (mysqli_query($conn,"SELECT * FROM security WHERE Email='$email'")->num_rows>0) {
        echo "<script> alert(' $email is taken use other email'); </script>";
      }else{
 //sql statement
 $sql= "INSERT INTO security (Name,Lname,Email,Password,role) values('$name','$lname','$email','$password','$role')";
 //query
 $qry=mysqli_query($conn,$sql) or die("data insert error");
 if ($qry) {
   echo "data inserted successfuly";
 }
  }
    }
    else{echo "<script> alert(' password mis match!'); </script>";}   
  
  } else {echo "<script> alert(' $email is not a valid email address!'); </script>";} 
  }

}
  
    
  
  function test_input($data) {
    
    $data = trim($data);
    $data = stripslashes($data);
    $data = htmlspecialchars($data);
    return $data;
  }

?>