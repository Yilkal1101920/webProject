<?php
session_start();
include_once("../database/db.php");
if($_SERVER["REQUEST_METHOD"]=="POST")
{
    $email = $_POST["Uemail"];
    $password = $_POST["Upassword"];
    //$role = $_POST["role"];
    //sql statement
    $sql=" SELECT * FROM security WHERE Email='$email' && Password= '$password'";
    
    $result=mysqli_query($conn,$sql);
    $count=mysqli_num_rows($result);

    $row = mysqli_fetch_array($result);

    if ($count==1) 
    {
      $result=mysqli_query($conn,"SELECT * FROM security WHERE role='$_SESSION[role]' " );
       //$result=mysqli_query($conn,'SELECT * FROM security WHERE role= $role ');
       if($row['role']=="admin12"){
        $_SESSION['user']=$email;
        header("location:../admin/index.php");
      }
      //($row['role']=="User")
      else{
        $_SESSION['user']=$email;
        header("location:../user/index.php");
      }

    }
    else{
        echo "<script> alert(' wrong password or username!'); </script>";
       }
      }
?>


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login</title>
    <script type="text/javascript" src="">
    // function validateform()
    // {
    //     var name = document.myform.username.value;
    //     var password = document.myform.password.value;

    //     if ( name == null || name == "" )
    //     {
    //         alert( "Name can't be blank" );
    //         return false;
    //     } else if ( password.length < 6 )
    //     {
    //         alert( "Password must be at least 6 characters long." );
    //         return false;
    //     }
    // }
</script>
<style>   
.login
{
   
    border: 15px solid blanchedalmond ;
    border-style: outside;
    border-radius: 50px;
    margin-top: 50px ;
    margin-left: 450px;
    margin-bottom: 0px;
    text-align: center;
     content: "";
    display: inline-block;
     width: 60%;
    height: 90%;
    position: relative;
    background-color: darkgrey;
    color: white;
    font-size: 30px;
    /* border-radius: 300px; */
    
    
}
 
a:link{
  display: inline-block;
  color: white;
  text-align: center;
  padding: 14px 16px;
  text-decoration: none;
  background-color: grey;
}
/* .assign
{
     text-align: center;
     position:50%;
     margin-top: 100x;
} */
.imgcontainer 
{
  text-align: center;
  margin: 24px 0 12px 0;
  border-radius: 50%;
}
img
{
  width: 70px;
  height: 80px
}
body{
 
  min-height: 100%;
  width: auto;
  background-color:white;
}
</style>
<script>
function validateForm() {
  let x = document.forms["myForm"]["Uemail"].value;
  let y = document.forms["myForm"]["Upassword"].value;
  //let z = document.forms["myForm"]["role"].value;
  if (x == ""||y=="") {
    alert("user name and password must be filled out");
    return false;
  }
}
</script>
</head>
<body>
<div class="login">
                <h2> Sign in Your Account</h2>
                <form action=""  METHOD="POST" name="myForm" onsubmit="return validateForm()">
                    
                <img src="profile.png" alt="Avatar" class="avatar imgcontainer">
                    <label><h3>username</h3></label>  
                    <input type="email"  name="Uemail" style="font-size: 25px"><br><br>
                    <label><h3>password</h3></label> 
                    <input type="password"  name="Upassword" style="font-size: 25px"><br><br>
                    <!-- <label >
                      <input type="checkbox" name="remember" value="1">
                      Keep me signed in
                    </label>
                    <br><br> -->
                    <input type="submit" value="login" style="font-size: 25px;" name="login">
                   
                    
                </form>
                <h3>Don't have an account ? <a href="reg.php">Create account</a></h3>       
    </div>
</body>
</html>
