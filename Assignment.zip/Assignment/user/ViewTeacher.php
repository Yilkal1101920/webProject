<?php
require_once('../database/db.php');
require_once('../UserHeader/userHeader.php');
$id=0;
$count=0;
$tid='';$tname;$tfname='' ; $tmobile='';$qualify='';$assign='' ; $year='';$semester='';
$result=mysqli_query($conn,'SELECT * FROM teacher');
while(mysqli_fetch_array($result)){
  $count++;
}

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Teacher Registration</title>
    <style>
      table {
  border-collapse: collapse;
  border-spacing: 0;
  width: 80%;
  border: 2px solid black;
}

th, td {
  text-align: left;
  padding: 10px;
  border: 2px solid black;
  font-size: 25px;
  
}

tr:nth-child(even) {
  background-color: gray;
}

      .search{
          float: right;
          background-color: gray;
          font-size: 20px;
          margin-right: 1px;
          margin-top: 15px;
      }
   
     
      
      .edit{
        font-size: 19px;
        width: 100%;
        height: fit-content;
        background-color: gray;
        border-radius: 15px;
        border: 5px solid black;
       
      }
   .content{
        margin-top: 200px;
      }
#myInput {
  background-image: url('fa fa-search');
  background-position: 10px 10px;
  background-repeat: no-repeat;
  width: 100%;
  font-size: 16px;
  padding: 12px 20px 12px 40px;
  border: 1px solid #ddd;
  margin-bottom: 12px;
  margin-right: 300px;
  float: right;
}
     
    </style>
</head>
<body>
<script>
//search item from table
function myFunction() {
  // Declare variables
  var input, filter, table, tr, td, i, txtValue;
  input = document.getElementById("myInput");
  filter = input.value.toUpperCase();
  table = document.getElementById("myTable");
  tr = table.getElementsByTagName("tr");

  // Loop through all table rows, and hide those who don't  match the search query
  for (i = 0; i < tr.length; i++) {
    td = tr[i].getElementsByTagName("td")[1];
    if (td) {
      txtValue = td.textContent || td.innerText;
      if (txtValue.toUpperCase().indexOf(filter) > -1) {
        tr[i].style.display = "";
      } else {
        tr[i].style.display = "none";
      }
    }
  }
}
</script>  
  <div class="content">
  <h2 style="text-align: center;"> Registered Teachers</h2>
    <a href="searchTeacher.php"><button class="search">SearchById</button></a>
    <form action="#" method="POST">
    <input type="text" id="myInput" onkeyup="myFunction()" placeholder="Search for names.." style="width: 550px;">
     <input type="hidden"  name="hid" value="$_POST['hid']"><br><br>
    
   
<table  id="myTable">
  <thead>
    <tr>
     
     <td><b>ID.NO</b></td>
    <td><b>Name</b></td>
    <td><b>Fname</b></td>
    <td><b>MObile.NO</b></td>

    <td><b>Qualification</b></td>
    <td><b>Course</b></td>
    <td><b>Semester</b></td>
    <td><b>Year</b></td>
    
      
    </tr>
  </thead>
  <tbody>
 

      <?php 
         echo "<h2> Total Records=".$count."</h2>";
          $result=mysqli_query($conn,'SELECT * FROM teacher');

        while($row = mysqli_fetch_array($result)){
         
          echo "<tr>";
               
                echo "<td>" . $row['Tid'] . "</td>";
                echo "<td>" . $row['Name'] . "</td>";
                echo "<td>" . $row['Fname'] . "</td>";
                echo "<td>" . $row['mobile'] . "</td>";

                echo "<td>" . $row['Qualification'] . "</td>";
                echo "<td>" . $row['Course'] . "</td>";
                echo "<td>" . $row['Semester'] . "</td>";
                echo "<td>" . $row['Year'] . "</td>";
             echo "</tr>";
        }
      ?>

  </tbody>
</table>
  </div>
<?php include_once("../footer/Footer.php"); ?>
</body>
</html>