<?php
require_once('../database/db.php');
require_once('../UserHeader/userHeader.php');
include_once("../security/session.php");

?>
<!DOCTYPE html>

<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>searching page</title>
    <style>
table {
  border-collapse: collapse;
  width: 80%;
}
table,th,tr,td{
    border: 2px solid green;
}

th, td {
  text-align: left;
  padding: 8px;
  font-size: 25px;
}
#search{
    margin: 50px;
    float: right;
    margin-right: 15px;
    height: 50%;
    border-radius: 10px;
   
}
.searchBtn{
  background-color: lemonchiffon;
  height: 35px;
  font-size: 25px;
}

tr {background-color: #f2f2f2;}
body{
  background-color: white;
}
.content{
  margin-top: 300px;
}
</style>
</head>
<body>
<div class="content">
  
<div class="course">
   <form class="" method="POST">
		
        <div id="search"><input type="text" name="id_search"  placeholder="Enter id"
              value="" style="height:30px;width:50%;margin-top:10px;font-size: 20px;">
             <button name="searchById" class="searchBtn" >search by id</button>
            </div>
            <br><br>
             <br><br>
      <table  class="mytable"  >
                     <thead style="text-align: center;">
                            <tr>
                             <td><b>Student.ID</b></td>
                            <td><b>Name</b></td>
                            <td><b>Last Name</b></td>
                            <td><b>Department</b></td>
                            <td><b>Semseter</b></td>
                            <td><b>Year</b></td>
                            <td><b>Registration Date</b></td>
                            </tr>
                     </thead>
                          <tbody>
                              <?php 
                         
                         if (isset($_POST['searchById'])) {
                         
                            $id=$_POST['id_search'];
                            
                            $result=mysqli_query($conn,"SELECT * FROM student_registration WHERE Stud_id= $id  " );
                           
                               
                         if(mysqli_num_rows($result)>0){
                                while($row = mysqli_fetch_array($result)){
                                  
                                    echo "<tr>";
                                        
                                    echo "<td>" . $row['Stud_id'] . "</td>";
                                    echo "<td>" . $row['Name'] . "</td>";
                                    echo "<td>" . $row['Fname'] . "</td>";
                                    echo "<td>" . $row['Department'] . "</td>";
                                    echo "<td>" . $row['Semester'] . "</td>";
                                    echo "<td>" . $row['Year'] . "</td>";
                                    echo "<td>" . $row['Regdate'] . "</td>";
                                    
                                 echo "</tr>";
                                }
                              }else{echo "<tr>". "<h1>No records found for this id</h1>".  " </tr>";}
                             
                              }
                              ?>
                         
                          </tbody>
               
                        <br><br>

                 </table>
                      </form>
          

</div>

</div>
<?php include '../footer/Footer.php'; ?>
</body>
</html>
