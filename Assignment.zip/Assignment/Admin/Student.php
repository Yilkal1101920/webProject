<?php
require_once('../database/db.php');
require_once('../Header/Header.php');
include_once("../security/session.php");
    $count=0;
    $id=0;
    
    $sid=''; $name='';$fname='';$department=''; $semester=''; $year='';
//insert student data
    if (isset($_POST['save'])) {
        
             $sid=$_POST['studentId'];
             $name=$_POST['studentName'];
             $name=$_POST['studentName'];
            $fname=$_POST['studentFatherName'];
            $department=$_POST['studentDepartment'];
            $semester=$_POST['semester'];
            $year=$_POST['year'];
      

      
       
        $sql= "INSERT INTO `student_registration`(`Stud_id`, `Name`, `Fname`, `Department`, `Semester`, `Year`) 
           
        VALUES ('$sid','$name','$fname','$department','$semester','$year')";

            $qry=mysqli_query($conn,$sql) or die("data insert error");
            
            $sid=''; $name='';$fname='';$department=''; $semester=''; $year='';
           
          }
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <!-- <link rel="stylesheet" type="text/css" href="style.css"> -->
    <title>Student</title>
    <style>
        body{
            background-color:white;
        }
        .student
        {
            padding-left: 200px;
            border: 10px solid darkkhaki;
            width: 50%;
            height: 100%;
            margin-left: 150px;
            margin-bottom: 0px;
            margin-top: 10px;
            font-size: 30px;
            font-weight: bold;
            background-color: darkgrey;
            border-radius: 60px;

        }

        .saveBtn{
            font-size: 25px;
            margin-bottom: 30px;
            background-color: gray;
            margin-left: 100px;
        }
        #ViewStudent{
            float: right;
            font-size: 30px;
            text-decoration: none;
            background-color: white;
            border: 20px solid lightslategrey ;
            margin-right: 10px;
        }
        h1{
            text-align: center;
           
        }
        .content{
            margin-top: 300px;
        }
        .error{
            color: crimson;
        }
    
    </style>
    
</head>
<body>
   <div class="content">


  
    <a href="ViewStudent.php" id="ViewStudent">View Student List</a>
    <form action="" method="POST">
        
        <div class="student">
        <h4> Student Register Form</h4> 
        <p><span class="error">* required field</span></p>
         
          ID <input type="text" placeholder="Enter Student Id" name="studentId" required value="<?php echo $sid;     ?>" 
        style="height:30px;width:40%;margin-left:150px;margin-top:10px;font-size: 22px;" ><span class="error">* </span><br><br>
   
        Name <input type="text" placeholder="Enter Student Name" name="studentName" required value="<?php echo $name;     ?>" 
        style="height:30px;width:40%;margin-left:110px;margin-top:10px;font-size: 22px;" ><span class="error">* </span><br><br>
           
        Father Name <input type="text" placeholder="Enter Student Father  Name" name="studentFatherName" required value="<?php echo $fname;     ?>"
         style="height:30px;margin-left:20px;width:40%;margin-top:10px;font-size: 22px;" ><span class="error">* </span><br><br>
       Department <input type="text" placeholder="Enter Department" name="studentDepartment" required value="<?php echo $department;     ?>" 
       style="height:30px;margin-left:30px;width:40%;margin-top:10px;font-size: 22px;" ><span class="error">* </span><br><br>
        
        <p>Semester
        <select name="semester" required value="<?php echo $semester;     ?>" style="height:30px;width:40%;margin-top:10px;margin-left:70px;font-size: 22px" >
           <option value="" >Semester</option>
             <option value="1" >1</option>
             <option value="2"> 2</option>
             
        </select><span class="error">* </span>
        </p><br>
        <p >Year
            <select name="year" required value="<?php echo $year;     ?>" style="height:30px;width:40%;margin-top:10px;font-size: 22px;margin-left:130px;" >
             <option value="Year" >year</option>
               <option value="1" >1</option>
               <option value="2"> 2</option>
               <option value="3">3</option>
               <option value="4"> 4</option>
               <option value="5">5</option>
               
            </select><span class="error">* </span>
            </p>
          <input type="submit" class="saveBtn" name ="save" value="save" />
          
          <input type="hidden" name="id" value="<?php echo $id;  ?> ">
             
    </form>
        </div>
   </div>



       

    <!-- <?php
include_once("../footer/Footer.php");
    ?> -->
</body>
</html>
