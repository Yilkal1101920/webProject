<?php
require_once('../database/db.php');
require_once('../Header/Header.php');
if(isset($_GET['StudentDelete'])){

   
    
    //$id=$_GET['delete'];
	mysqli_query($conn,"DELETE FROM student_registration WHERE Id='$_GET[StudentDelete]' ");

	header("location:ViewStudent.php");

}
?>