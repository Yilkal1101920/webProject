<!DOCTYPE html>
<html>

    <head>
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <style>
            body {
                font-family: Arial, Helvetica, sans-serif;
                margin: 0;
            }

            html {
                box-sizing: border-box;
            }

            *,
            *:before,
            *:after {
                box-sizing: inherit;
            }

            .column {
                float: left;
                width: 33.3%;
                margin-bottom: 16px;
                padding: 0 8px;
            }

            .card {
                box-shadow: 0 4px 8px 0 rgba(0, 0, 0, 0.2);
                margin: 8px;
            }

            .about-section {
                padding: 50px;
                text-align: center;
                background-color: #474e5d;
                color: white;
                font-size: 25px;
            }

            .container {
                padding: 0 16px;
            }

            .container::after,
            .row::after {
                content: "";
                clear: both;
                display: table;
            }

            .title {
                color: grey;
            }

            .button {
                border: none;
                outline: 0;
                display: inline-block;
                padding: 8px;
                color: white;
                background-color: #000;
                text-align: center;
                cursor: pointer;
                width: 100%;
            }

            .button:hover {
                background-color: #555;
            }

            @media screen and (max-width: 650px) {
                .column {
                    width: 100%;
                    display: block;
                }
            }
            img{
                width :90px !important;
                height: 90px !important;
                
            }

        </style>
    </head>

    <body>
<?php  include("../Header/Header.php");?>
        <div class="about-section">
            <h1>Well come to  abou us page </h1>
            <p>We are 3rd Year Software Enginnering Students </p>
            <p>we made  course managments ystem simple web application  </p>
            <p>for more information pleace contact us</p>
        </div>

        <h2 style="text-align:center">Our Team Members</h2>
        <div class="row">
            <div class="column">
                <div class="card">
                    <img src="../profilephoto/muluneh.jpg" alt="Muluneh Meri" width="100%">
                    <div class="container">
                        <h2>Muluneh Meri</h2>
                        <h3>ID=1102199</h3>
                        <p class="title">Designer</p>
                        <p>I am a designer for this project</p>
                        <p>mulunehmeri@gmail.com</p>
                        <p><a href="mailto:mulunehmeri@gmail.com"><button class="button">contact me</button></a></p>
                    </div>
                </div>
            </div>

            <div class="column">
                <div class="card">
                    <img src="../profilephoto/img4.jpg" alt="Temesigen" style="width:100%">
                    <div class="container">
                        <h2>Temesgen Asmamaw</h2>
                        <h3>ID=1102195</h3>
                        <p class="title">implmenter</p>
                        <p>I am an implmenter in this project</p>
                        <p>asmamawtemesgen16@gmail.com</p>
                        <p><a href="mailto: asmamawtemesgen16@gmail.com"><button class="button">contact me</button></a></p>
                    </div>
                </div>
            </div>

            <div class="column">
                <div class="card">
                    <img src="../profilephoto/getalem.jpg" alt="John" style="width:100%">
                    <div class="container">
                        <h2>Getalem Berihun</h2>
                        <h3>ID=1103393</h3>
                        <p class="title">designer</p>
                        <p>I am a designer in this project</p>
                        <p>getalemberihun23@gmail.com</p>
                        <p><a href="mailto:getalemberihun23@gmail.com"><button class="button">contact me</button></a></p>
                    </div>
                </div>
            </div>
            <div class="column">
                <div class="card">
                    <img src="../profilephoto/yilikal.jpg" alt="John" style="width:100%">
                    <div class="container">
                        <h2>Yilkal Derseh</h2>
                        <h3>ID=1101920</h3>
                        <p class="title">Tester</p>
                        <p>I am work as a tester in this project</p>
                        <p>yilkalderseh@gmail.com</p>
                         <p><a href="mailto:yilkalderseh@gmail.com"><button class="button">contact me</button></a></p>
                    </div>
                </div>
            </div>
            <div class="column">
                <div class="card">
                    <img src="../profilephoto/wudneh.jpg" alt="John" style="width:100%">
                    <div class="container">
                        <h2>Wudneh Birhan</h2>
                        <h3>ID=1101907</h3>
                        <p class="title">Secretary</p>
                        <p> I am a secretary in this project</p>
                        <p>wudnehbirhan@gmail.com</p>
                        <p><a href="mailto:yilkalderseh@gmail.com"><button class="button">contact me</button></a></p>
                    </div>
                </div>
            </div>
            <div class="column">
                <div class="card">
                    <img src="../profilephoto/aweke.jpg" alt="Aweke" style="width:100%">
                    <div class="container">
                        <h2>Aweke Dessie</h2>
                        <h3>ID=1101</h3>
                        <p class="title">Requimente Collocter</p>
                        <p> I am a REquimente collocter in this project</p>
                        <p>awekedessie@gmail.com</p>
                        <p><a href="mailto:awekedessie@gmail.com"><button class="button">contact me</button></a></p>
                    </div>
                </div>
            </div>
            <div class="column">
                <div class="card">
                    <img src="../profilephoto/tadiyos.jpg" alt="Aweke" style="width:100%">
                    <div class="container">
                        <h2>Tadiose Anteneh</h2>
                        <h3>ID=1102080</h3>
                        <p class="title">Requimente Collocter</p>
                        <p> I am a REquimente collocter in this project</p>
                        <p>tadi@gmail.com</p>
                        <p><a href="mailto:tadi@gmail.com"><button class="button">contact me</button></a></p>
                    </div>
                </div>
            </div>
            <!-- <div class="column">
                <div class="card">
                    <img src="profilephoto/tadiyos.jpg" alt="Tdiyos" style="width:100%">
                    <div class="container">
                        <h2>Tadiyos </h2>
                        <h3>ID=1101</h3>
                        <p class="title">REquimente collocter</p>
                        <p> I am a REquimente collocter in this project</p>
                        <p>tadi@gmail.com</p>
                        <p><a href="mailto:tadi@gmail.com"><button class="button">contact me</button></a></p> 
                    </div>
                </div>
            </div> -->
            
        </div>
       <?php include ('../footer/footer.php'); ?>
    </body>

</html>
