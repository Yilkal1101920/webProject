<?php
require_once('../database/db.php');
require_once('../Header/Header.php');
$id=0;
$count=0;
$cid='';$cname='';$cfname='' ; $credit='';$semester='';$year='' ; $category='';

$result=mysqli_query($conn,'SELECT * FROM course');

while(mysqli_fetch_array($result)){
  $count++;
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Teacher Registration</title>
    <style>
    table {
  border-collapse: collapse;
  border-spacing: 0;
  width: 80%;
  border: 2px solid black;
}

th, td {
  text-align: left;
  padding: 10px;
  border: 2px solid black;
  font-size: 30px;
  
}

tr:nth-child(even) {
  background-color: gray;
}

      .search{
          float: right;
          background-color: gray;
          font-size: 30px;
          margin-right: 1px;
          margin-top: 15px;
          border: 10px solid gray;
      }
     
      h2{
        color: red;
        font-weight: italic;
      }
      body{
        background-color: white;
      }
      .edit{
        font-size: 19px;
        width: 100%;
        height: fit-content;
        border-radius: 15px;
        background-color: gray;
      }
.content{
  margin-top: 300px;
}
#myInput {
  background-image: url('/css/searchicon.png');
  background-position: 10px 10px;
  background-repeat: no-repeat;
  width: 100%;
  font-size: 16px;
  padding: 12px 20px 12px 40px;
  border: 1px solid #ddd;
  margin-bottom: 12px;
  margin-right: 300px;
  float: right;
}
     
    </style>
</head>
<body>
<script>
//search item from table
function myFunction() {
  // Declare variables
  var input, filter, table, tr, td, i, txtValue;
  input = document.getElementById("myInput");
  filter = input.value.toUpperCase();
  table = document.getElementById("myTable");
  tr = table.getElementsByTagName("tr");

  // Loop through all table rows, and hide those who don't match the search query
  for (i = 0; i < tr.length; i++) {
    td = tr[i].getElementsByTagName("td")[1];
    if (td) {
      txtValue = td.textContent || td.innerText;
      if (txtValue.toUpperCase().indexOf(filter) > -1) {
        tr[i].style.display = "";
      } else {
        tr[i].style.display = "none";
      }
    }
  }
}
</script>  
<div class="content">
<a href="SearchCourse.php"><button class="search">SearchById</button></a>

<h1>Registered Courses</h1>
<form action="#" method="POST">
<input type="text" id="myInput" onkeyup="myFunction()" placeholder="Search for names.." style="width: 550px;">

<table  id="myTable"  >
<thead style="text-align: center;">
<tr>
 <td><b>Code</b></td>
<td><b>Title</b></td>
<td><b>Credit</b></td>
<td><b>Semseter</b></td>
<td><b>Year</b></td>
<td><b>category</b></td>
<td colspan="2"><b>Action</b></td>
</tr>
</thead>
<tbody>
  <?php 
     echo "<h1> Total Records=".$count."</h1>";
      $result=mysqli_query($conn,'SELECT * FROM course');
    while($row = mysqli_fetch_array($result)){
 
      echo "<tr>";
            
            echo "<td>" . $row['Code'] . "</td>";
            echo "<td>" . $row['Title'] . "</td>";
            echo "<td>" . $row['Credit'] . "</td>";
            echo "<td>" . $row['Semester'] . "</td>";

            echo "<td>" . $row['Year'] . "</td>";
            echo "<td>" . $row['Category'] . "</td>";
        
            echo "<td>";?><a href="UpdateCourse.php? CourseEdit=<?php echo $row['Id'];?>"><button class="edit" type="button" style="background-color: green" >Edit</button></a> <?php echo"</td>";
            echo "<td>"; ?><a href="DeleteCourse.php?CourseDelete=<?php echo $row['Id'];?>"><button class="edit" type="button"  id="del" style="background-color: crimson;">Delete</button></a> <?php echo"</td>";
         echo "</tr>";
  }


  ?>

</tbody>
</table>
</div>
<?php include_once("../footer/Footer.php"); ?>
</body>
</html>