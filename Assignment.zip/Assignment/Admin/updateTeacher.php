<?php
require_once('../database/db.php');
require_once('../Header/Header.php');
$tid='';
$name='';
$fname='' ; 
$mobile='';
$qulify='';
$assign='' ; 
$semester='';
$year='';

$count=0;

if (isset($_GET['edit'])) {
    
    $id=$_GET['edit'];
    $sql=mysqli_query($conn,"SELECT * FROM teacher WHERE Id='$id' " );
    $count=mysqli_num_rows($sql);
    if ($count==1) {

        $rows = mysqli_fetch_array($sql);
        $tid=$rows['Tid'];
        $name=$rows['Name'];
        $fname=$rows['Fname'] ;
        $mobile=$rows['mobile'];

        $qualify=$rows['Qualification'];
        $assign=$rows['Course'] ;
        $semester=$rows['Semester'];
        $year=$rows['Year'];
        
       
      }
    }
//updating of data
 if (isset($_POST['update'])) {
 
    $id=$_POST['id'];  
     $name=$_POST['teacherName'];
     $fname=$_POST['teacherFatherName'];
     $mobile=$_POST['teachermobile'];

 $tid=$_POST['teacherId'];
$qualify=$_POST['qualify'];
$assign=$_POST['assign'];
$semester=$_POST['semester'];
$year=$_POST['year'];
    
   
   mysqli_query($conn,"UPDATE `teacher` SET `Tid`='$tid',`Name`='$name',`Fname`='$fname', `mobile`='$mobile',`Qualification`='$qualify',`Course`='$assign', `Semester`='$semester',`Year`='$year' WHERE Id=$id ");
   header("location:ViewTeacher.php");
 }

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Teacher Registration</title>
    <style>
        
        .updateTeacher{
            padding-left: 200px;
            border: 10px solid darkgray;
            width: 50%;
            height: 100%;
            margin-left: 150px;
            margin-bottom: 0px;
            margin-top: 10px;
            font-size: 30px;
            font-weight: bold;
            background-color: gainsboro;
            border-radius: 60px;

        }
        .updateBtn{
            font-size: 25px;
            margin-bottom: 30px;
            background-color: gray;
            margin-left: 100px;
        }
        h1{
            text-align: center;
           
        }
        .content{
        margin-top: 200px;
      }
    </style>
</head>
<body>
 <div class="content">
        
<div class="updateTeacher">

<h1> Update Teacher information</h1>
    <form action="#" method="POST">
 
    <input type="hidden" name="id" value="<?php echo $id;  ?> ">
            ID.No <input type="text" placeholder="Enter Teacher ID"     name="teacherId"      value="<?php echo $tid ;  ?>" style="margin-left:110px;height:30px;width:40%;margin-top:10px; font-size: 23px;"><br><br>
            Name <input type="text" placeholder="Enter Teacher Name"     name="teacherName"      value="<?php echo $name ;  ?>" style="margin-left:110px;height:30px;width:40%;margin-top:10px;font-size: 23px;"><br><br>
            Last Name <input type="text" placeholder="Enter Father Name"     name="teacherFatherName"      value="<?php echo $fname ;  ?>" style="margin-left:50px;height:30px;width:40%;margin-top:10px;font-size: 23px;"><br><br>
            Mobile <input type="number" placeholder="Enter phone number"   name="teachermobile"    value="<?php echo $mobile ;  ?>" style="margin-left:95px;height:30px;width:40%;margin-top:10px;font-size: 23px;"><br><br>
            Qualification <input type="text" placeholder="Teacher qualification" name="qualify"      value="<?php echo $qualify;   ?>" style="margin-left:20px;height:30px;width:40%;margin-top:10px;font-size: 23px;"><br><br>
            Assigned <input type="text" placeholder="Assign course "          name="assign"    value="<?php echo $assign ;  ?>" style="margin-left:67px;height:30px;width:40%;margin-top:10px;font-size: 23px;"><br><br>
            Semester <input type="text" placeholder="semester Who teach it"      name="semester"      value="<?php echo $semester ;  ?>" style="margin-left:70px;height:30px;width:40%;margin-top:10px;font-size: 23px;"><br><br>
            Year <input type="text" placeholder="Year who teach it"             name="year"      value="<?php echo $year  ; ?>" style="margin-left:120px;height:30px;width:40%;margin-top:10px;font-size: 23px;"><br><br>
            
      
            </p>
            <input type="submit" name="update" value="update" class="updateBtn">
    </form>
  
</div>
 </div>
   
<?php include_once("../footer/Footer.php"); ?>
</body>
</html>