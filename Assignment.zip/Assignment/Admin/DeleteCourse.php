<?php
require_once('../database/db.php');
require_once('../Header/Header.php');
if(isset($_GET['CourseDelete'])){

   
    
    //$id=$_GET['delete'];
	mysqli_query($conn,"DELETE FROM course WHERE Id='$_GET[CourseDelete]' ");

	header("location:ViewCourse.php");

}
?>