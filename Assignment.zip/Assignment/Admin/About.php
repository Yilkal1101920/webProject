<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>About</title>
    <style>
        .about{
            font-size: 30px;
            font-weight: lighter;
            margin-left: 100px;
            margin-right: 100px;
            margin-top: 250px;
        }
        #more {display: none;}
        #myBtn{
            background-color: gray;
            margin-left: 200px;
            font-size: 25px;
        }
        h1{
            text-align: center;
            color: black;
        }
    </style>
</head>
<body>
<?php 
include_once("../Header/Header.php");
?>

<div class="about">

<h3>Below are all about this website</h3>
<p>A course management system (CMS) is a collection of software tools providing an online environment for course interactions.
    <span id="dots">...</span><span id="more">
    CMS is typically integrated with other databases in the university so that students enrolled in a particular course are automatically registered in the CMS as participants in that course.

The decision to use a CMS in a traditional face-to-face course has implications for course design that often go unnoticed by instructors in their initial use of such systems. This module lists technical and pedagogical tips that instructors should consider as they place materials into a CMS. While it is intended primarily for instructors who are using a CMS for the first time, instructors who have already used a CMS in other courses might benefit by using these tips as a checklist.</span></p>
<button onclick="myFunction()" id="myBtn">Read more</button>
</div>

<script>
function myFunction() {
  var dots = document.getElementById("dots");
  var moreText = document.getElementById("more");
  var btnText = document.getElementById("myBtn");

  if (dots.style.display === "none") {
    dots.style.display = "inline";
    btnText.innerHTML = "Read more"; 
    moreText.style.display = "none";
  } else {
    dots.style.display = "none";
    btnText.innerHTML = "Read less"; 
    moreText.style.display = "inline";
  }
}
</script>
<?php 

include_once("../footer/footer.php");
?>
</body>
</html>