<?php
require_once('../database/db.php');
require_once('../Header/Header.php');
include_once("../security/session.php");
$sid=''; $name='';$fname='';$department=''; $semester=''; $year='';
$count=0;

if (isset($_GET['StudentEdit'])) {
    
    $id=$_GET['StudentEdit'];
    $sql=mysqli_query($conn,"SELECT * FROM student_registration WHERE ID='$id' " );
    $count=mysqli_num_rows($sql);
    if ($count==1) {
        $rows = mysqli_fetch_array($sql);

        $sid=$rows['Stud_id'];
        $name=$rows['Name'];
        $fname=$rows['Fname'] ;
        $department=$rows['Department'];
        $semester=$rows['Semester'];
        $year=$rows['Year'] ;
        
        
       
      }
    }
//updating of data
 if (isset($_POST['update'])) {
 
    $id=$_POST['id'];

    $sid=$_POST['StudentId'];
     $name=$_POST['StudentName'];
     $fname=$_POST['LastName'];
     $department=$_POST['Department'];
     $semester=$_POST['Semester'];
     $year=$_POST['year'];

    
   
     mysqli_query($conn,"UPDATE `student_registration` SET `Stud_id`='$sid',`Name`='$name',`Fname`='$fname',
     `Department`='$department',`Semester`='$semester',`Year`='$year' WHERE ID=$id ");
   header("location:ViewStudent.php");
   
 }

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Update Students</title>
    <style>
        
        .updateSudent{
            padding-left: 200px;
            border: 10px solid blue;
            width: 50%;
            height: 100%;
            margin-left: 150px;
            margin-bottom: 0px;
            margin-top: 10px;
            font-size: 30px;
            font-weight: bold;
            background-color: whitesmoke;
            border-radius: 60px;

        }
        .updateBtn{
            font-size: 25px;
            margin-bottom: 30px;
            background-color: gray;
            margin-left: 100px;
        }
        h1{
            text-align: center;
           
        }
        .content{
            margin-top: 300px;
        }
    </style>
</head>
<body>

<div class="content">

<div class="updateSudent">
<h1> Update Student</h1>
    <form action="#" method="POST">
    <input type="hidden" name="id" value="<?php echo $id;  ?> ">
            ID.No <input type="text" placeholder="Enter Student ID"     name="StudentId"      value="<?php echo $sid ;  ?>" style="margin-left:90px;height:30px;width:40%;margin-top:10px;font-size: 23px;"><br><br>
            Name <input type="text" placeholder="Enter Student Name"     name="StudentName"      value="<?php echo $name ;  ?>" style="margin-left:95px;height:30px;width:40%;margin-top:10px;font-size: 23px;"><br><br>
            Last Name <input type="text" placeholder="Student last name"   name="LastName"    value="<?php echo $fname ;  ?>" style="margin-left:35px;height:30px;width:40%;margin-top:10px;font-size: 23px;"><br><br>
            Department <input type="text" placeholder="Student department" name="Department"      value="<?php echo $department;   ?>" style="margin-left:27px;height:30px;width:40%;margin-top:10px;font-size: 23px;"><br><br>
            Semester <input type="text" placeholder="semester "          name="Semester"    value="<?php echo $semester ;  ?>" style="margin-left:70px;height:30px;width:40%;margin-top:10px;font-size: 23px;"><br><br>
            Year <input type="text" placeholder="year"                   name="year"      value="<?php echo $year ;  ?>" style="margin-left:120px;height:30px;width:40%;margin-top:10px;font-size: 23px;"><br><br>
            
            
      
            </p>
            <input type="submit" name="update" value="update" class="updateBtn">
    </form>
</div>
  

</div>
<?php include_once("../footer/Footer.php"); ?>
</body>
</html>