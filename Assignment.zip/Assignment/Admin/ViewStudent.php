<?php
require_once('../database/db.php');
require_once('../Header/Header.php');
$id=0;
$count=0;
$sid=''; $name='';$fname='';$department=''; $semester=''; $year='';

$result=mysqli_query($conn,'SELECT * FROM student_registration');

while(mysqli_fetch_array($result)){
  $count++;
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Teacher Registration</title>
    <script src="js/jquery.min.js"></script>

    <style>
  
table {
  border-collapse: collapse;
  border-spacing: 0;
  width: 80%;
  border: 2px solid black;
  
}

th, td {
  text-align: left;
  padding: 10px;
  border: 2px solid black;
  font-size: 27px;
  
}

tr:nth-child(even) {
  background-color: gray;
}

      .search{
          float: right;
          background-color: lavender;
         
          font-size: 20px;
          margin-right: 1px;
          margin-top: 15px;
      }
      h1{
        text-align: center;
        color: green;
      }
      h2{
       
        font-weight: italic;
      }
      body{
        background-color: white;
      }
      .edit{
        font-size: 19px;
        width: 100%;
        height: fit-content;
        background-color: gray;
        border-radius: 12px;
      }
      .content{
        margin-top: 200px;
      }
  #myInput {
  background-image: url('/css/searchicon.png');
  background-position: 10px 10px;
  background-repeat: no-repeat;
  width: 100%;
  font-size: 16px;
  padding: 12px 20px 12px 40px;
  border: 1px solid #ddd;
  margin-bottom: 12px;
  margin-right: 300px;
  float: right;
}
    </style>
</head>
<body>
<script>
//tableeeeeeeeeeeeeeeeeeeeeeeeeeeee
function myFunction() {
  // Declare variables
  var input, filter, table, tr, td, i, txtValue;
  input = document.getElementById("myInput");
  filter = input.value.toUpperCase();
  table = document.getElementById("myTable");
  tr = table.getElementsByTagName("tr");

  // Loop through all table rows, and hide those who don't match the search query
  for (i = 0; i < tr.length; i++) {
    td = tr[i].getElementsByTagName("td")[1];
    if (td) {
      txtValue = td.textContent || td.innerText;
      if (txtValue.toUpperCase().indexOf(filter) > -1) {
        tr[i].style.display = "";
      } else {
        tr[i].style.display = "none";
      }
    }
  }
}

</script>

  <div class="content">
  <a href="SearchStudent.php"><button class="search">SearchById</button></a>

<h1>List of Registered Sudents</h1>
<form action="#" method="POST" name="">
<input type="text" id="myInput" onkeyup="myFunction()" placeholder="Search for names.." style="width: 550px;">
<table  id="myTable" >
<thead style="text-align: center;">
<tr>
<td><b>Student ID</b></td>
 <td><b>Name</b></td>
<td><b>Last Name</b></td>
<td><b>Department</b></td>
<td><b>Semseter</b></td>
<td><b>Year</b></td>
<td><b>Reg.Date</b></td>
<td colspan="2"><b>Action</b></td>
</tr>
</thead>
<tbody id="myTable">
  <?php 
     echo "<h2> Total Record=".$count."</h2>";
      $result=mysqli_query($conn,'SELECT * FROM student_registration');
     // $join=mysqli_query($conn,'SELECT s.*,c.Year as cyear FROM student_registration s,course c where s.Year=c.year   ');
    while($row = mysqli_fetch_array($result)){
 
      echo "<tr>";
            
            echo "<td>" . $row['Stud_id'] . "</td>";
            echo "<td>" . $row['Name'] . "</td>";
            echo "<td>" . $row['Fname'] . "</td>";
            echo "<td>" . $row['Department'] . "</td>";

            echo "<td>" . $row['Semester'] . "</td>";
            echo "<td>" . $row['Year'] . "</td>";
            echo "<td>" . $row['Regdate'] . "</td>";
        
            echo "<td>";?><a href="UpdateStudent.php? StudentEdit=<?php echo $row['ID'];?>"><button type="button" style="background-color: green;" class="edit" >Edit</button></a> <?php echo"</td>";
            echo "<td>"; ?><a href="DeleteStudent.php?StudentDelete=<?php echo $row['ID'];?>"><button type="button"  id="del" style="background-color: crimson;" class="edit">Delete</button></a> <?php echo"</td>";
         echo "</tr>";
    }

   
  ?>

</tbody>
</table>
<?php include_once("../footer/Footer.php"); ?>
  </div>
</body>
</html>