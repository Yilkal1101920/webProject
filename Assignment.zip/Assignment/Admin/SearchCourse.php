<?php
include_once("../security/session.php");
require_once('../database/db.php');
require_once('../Header/Header.php');


?>
<!DOCTYPE html>

<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>searching page</title>
    <style>
table {
  border-collapse: collapse;
  width: 80%;
}
table,th,tr,td{
    border: 2px solid green;
    font-size: 20px;
}

th, td {
  text-align: left;
  padding: 8px;
  font-size: 27px;
}
#search{
    margin: 50px;
    float: right;
    margin-right: 15px;
    height: 50%;
    border-radius: 10px;
   
}
.searchBtn{
  background-color: lemonchiffon;
  height: 35px;
  font-size: 25px;
}

tr {background-color: #f2f2f2;}
body{
  background-color:white;
}


tr {background-color: #f2f2f2;}
.content{
  margin-top: 320px;
}
</style>
</head>
<body>
<div class="content">
  
<div class="course">
   <form class="" method="POST">
		
        <div id="search">
          <input type="text" name="id_search"  placeholder="Enter id"  value="" style="height:30px;width:50%;margin-top:10px; font-size: 20px;">
          <!-- <input type="text" name="name_search"   value=""> -->
             <button name="searchById" class="searchBtn" >search by id</button>
            </div>
            </form>
            </div>
            <br><br>
           
             
             <br><br>
    
                 <table  class="mytable"  >
                     <thead style="text-align: center;">
                            <tr>
                             <td><b>Code</b></td>
                            <td><b>Title</b></td>
                            <td><b>Credit</b></td>
                            <td><b>Semseter</b></td>
                            <td><b>Year</b></td>
                            <td><b>category</b></td>
                            </tr>
                     </thead>
                          <tbody>
                              <?php 
                         
                         if (isset($_POST['searchById'])) {
                         
                            $id=$_POST['id_search'];
                           

                            $result=mysqli_query($conn,"SELECT * FROM course WHERE Code= $id" );

                            if(mysqli_num_rows($result)>0||$id==''){
                              while($row = mysqli_fetch_array($result)){
                             
                                echo "<tr>";
                                      
                                      echo "<td>" . $row['Code'] . "</td>";
                                      echo "<td>" . $row['Title'] . "</td>";
                                      echo "<td>" . $row['Credit'] . "</td>";
                                      echo "<td>" . $row['Semester'] . "</td>";
                                      echo "<td>" . $row['Year'] . "</td>";
                                      echo "<td>" . $row['Category'] . "</td>";
                                      
                                   echo "</tr>";
                              }
                            }
                            else{
                              echo "<h2>No records,wrong id</h2>";

                            }
                          
                              
                         
                            }


                              ?>
                         
                          </tbody>
               
                        <br><br>
                 </table>
                

</div>
                 <?php include_once("../footer/Footer.php"); ?>
</body>
</html>
