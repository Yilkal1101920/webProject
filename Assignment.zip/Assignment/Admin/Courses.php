<?php
require_once('../database/db.php');
include_once('../Header/Header.php');
$id=0;
$count=0;
$cid='';$cname='' ; $credit='';$semester='';$year='' ; $category='';

if(isset($_POST['save'])){
$cid=$_POST['CourseId'];
$cname=$_POST['courseName'];
$credit=$_POST['CourseCredit'];
$semester=$_POST['CourseSemester'];
$year=$_POST['CourseYear'];
$category=$_POST['CourseCategory'];


$sql=mysqli_query($conn,"INSERT INTO `course`( `Code`, `Title`, `Credit`, `Semester`, `Year`, `Category`) 

VALUES ('$cid','$cname','$credit','$semester','$year','$category')  ") or  die("data insert error");
}
$cid='';$cname='' ; $credit='';$semester='';$year='' ; $category='';
$result=mysqli_query($conn,'SELECT * FROM course');
while(mysqli_fetch_array($result)){
  $count++;
}
?>


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Course</title>
    <style>
        .myclass{
            background-color: gray;
            font-size: 20px;
            padding-left: 29px;
            margin: 0px;
        }

        .course{
            padding-left: 200px;
            border: 10px solid gray;
            width: 50%;
            height: 150%;
            margin-left: 280px;
            margin-bottom: 0px;
            margin-top: 10px;
            font-size: 30px;
            font-weight: bold;
            background-color:darkgrey;
            border-radius: 60px;

        }
        .registerBtn{
            font-size: 25px;
            margin-bottom: 30px;
            background-color: green;
            margin-left: 100px;
        }
        #ViewCourse{
            float: right;
            font-size: 30px;
            text-decoration: none;
            background-color: white;
            margin-right: 10px;
        }
        h1{
            text-align: center;
           
          
        }
      
        .content{
            margin-top: 300px;
        }
        .error{
            color: crimson;
        }
    </style>
    
</head>
<body>

<div class="content">
<h1>Register Courses</h1>
<div class="course">
<p><span class="error">* required field</span></p>
<form action="#" method="POST">
        
        Course code <input type="text" placeholder="Enter Course code" name="CourseId" value=""
         style="height:35px;margin-left:15px;width:40%;margin-top:10px;font-size: 20px;" required><span class="error">* </span><br><br>
        Course Name <input type="text" placeholder="Enter Course Name" name="courseName" value=""
         style="height:30px;margin-left:10px;width:40%;margin-top:10px;font-size: 20px;" required><span class="error">* </span><br><br>
        Credit <input type="number" placeholder="Enter Credit" name="CourseCredit" value=""
         style="height:30px;width:40%;margin-left:100px;margin-top:10px;font-size: 20px;" required><span class="error">* </span><br><br>
    
    <p>Semester
    <select name="CourseSemester" style="height:30px;width:40%;margin-top:10px;margin-left:70px;font-size: 20px;" required>
         <option value="1">Semester</option>
         <option value="2" >1</option>
         <option value="3"> 2</option> 
    </select><span class="error">* </span>
    </p>
    <p >Year
        <select name="CourseYear" style="height:30px;width:40%;margin-top:10px;margin-left:120px;font-size: 20px;" required >
          <option value="" >Year</option>
           <option value="1" >1</option>
           <option value="2"> 2</option>
           <option value="3">3</option>
           <option value="4"> 4</option>
           <option value="5">5</option>
           
        </select><span class="error">* </span>
        <br><br>
    Category <input type="text"  placeholder="Enter Category" name="CourseCategory" value=""
     style="height:30px;margin-left:60px;width:40%;margin-top:10px;font-size: 20px;" required><span class="error">* </span><br><br>
        </p>
        <tr>
        <input type="submit" class="registerBtn" value="Register" name="save" style="background-color:gray; text-align: center;">
        <a href="ViewCourse.php" id="ViewCourse">ViewCourse</a>

    
</form>

</div>
</div>

<?php include '../footer/footer.php'; ?> 
</body>
</html>