<?php
require_once('../database/db.php');
require_once('../Header/Header.php');
include_once("../security/session.php");
$cid='';$cname='' ; $credit='';$semester='';$year='' ; $category='';

$count=0;

if (isset($_GET['CourseEdit'])) {
    
    $id=$_GET['CourseEdit'];
    $sql=mysqli_query($conn,"SELECT * FROM course WHERE Id='$id' " );
    $count=mysqli_num_rows($sql);
    if ($count==1) {

        $rows = mysqli_fetch_array($sql);
        $cid=$rows['Code'];
        $cname=$rows['Title'];
        $credit=$rows['Credit'] ;
        $semester=$rows['Semester'];

        $year=$rows['Year'];
        $category=$rows['Category'] ;

      }
    }
//updating of data
 if (isset($_POST['update'])) {
 
$id=$_POST['id'];//for updating data
     $cid=$_POST['CourseId'];
     $cname=$_POST['courseName'];
     $credit=$_POST['CourseCredit'];
     $semester=$_POST['CourseSemester'];
     $year=$_POST['CourseYear'];
     $category=$_POST['CourseCategory'];

   
   mysqli_query($conn,"UPDATE `course` SET `Code`='$cid',`Title`='$cname',`Credit`='$credit',`Semester`='$semester',`Year`='$year',`Category`='$category' WHERE Id=$id ");
   header("location:ViewCourse.php");
 }

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Update Student</title>
    <style>
             body{
            background-color:white;
        }
        .updateCourse{
            padding-left: 200px;
            border: 10px solid blue;
            width: 50%;
            height: 100%;
            margin-left: 150px;
            margin-bottom: 0px;
            margin-top: 10px;
            font-size: 30px;
            font-weight: bold;
            background-color: whitesmoke;
            border-radius: 60px;

        }
        .updateBtn{
            font-size: 25px;
            margin-bottom: 30px;
            background-color: burlywood;
            margin-left: 100px;
        }
        h1{
            text-align: center;
           
        }
        .content{
          margin-top: 300px;
        }
    </style>
</head>
<body>
  <div class="content">
  <div class="updateCourse">
  <h1> Update Courses</h1>
    <form action="#" method="POST">
    <input type="hidden" name="id" value="<?php echo $id;  ?> ">

           Course code <input type="text" placeholder="Enter Course code" name="CourseId" value="<?php echo $cid ;  ?>"style="height:30px;width:40%;margin-top:10px;font-size: 23px;"><br><br>
            Course Name <input type="text" placeholder="Enter Course Name" name="courseName" value="<?php echo $cname ;  ?>" style="height:30px;width:40%;margin-top:10px;font-size: 23px;"><br><br>
            Credit <input type="number" placeholder="Enter Credit" name="CourseCredit" value="<?php echo $credit ;  ?>"style="margin-left:90px;height:30px;width:40%;margin-top:10px;font-size: 23px;"><br><br>

           
            Semester
            <input name="CourseSemester" type="number" value="<?php echo $semester ;  ?>"style="margin-left:60px;height:30px;width:40%;margin-top:10px;font-size: 23px;"><br><br>
           Year <input name="CourseYear" type="number" value="<?php echo $year ;  ?>"style="margin-left:110px;height:30px;width:40%;margin-top:10px;font-size: 23px;">
        
                <br><br>
            Category <input type="text"  placeholder="Enter Category" name="CourseCategory" value="<?php echo $category ;  ?>"style="margin-left:50px;height:30px;width:40%;margin-top:10px;font-size: 23px;"><br><br>
            
      
            </p>
            <input type="submit" name="update" value="update" class="updateBtn">
    </form>

  </div>
    
  </div>

  <?php include_once("../footer/Footer.php"); ?>
</body>
</html>