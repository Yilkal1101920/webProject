<?php
require_once('../database/db.php');
require_once('../Header/Header.php');
if(isset($_GET['delete'])){

   
    
    //$id=$_GET['delete'];
	mysqli_query($conn,"DELETE FROM teacher WHERE Id='$_GET[delete]' ");

	header("location:ViewTeacher.php");

}
?>