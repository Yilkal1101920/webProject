<?php
require_once('../database/db.php');
require_once('../Header/Header.php');
include_once("../security/session.php");

?>
<!DOCTYPE html>

<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>searching page</title>
    <style>
table {
  border-collapse: collapse;
  width: 80%;
}
table,th,tr,td{
    border: 2px solid green;
}

th, td {
  text-align: left;
  padding: 8px;
}
#search{
    margin: 50px;
    float: right;
    margin-right: 15px;
    height: 50%;
    border-radius: 10px;
   
}
.searchBtn{
  background-color: lemonchiffon;
  font-size: 25px;
  
}

tr {background-color: #f2f2f2;}
body{
  background-color: white;
}
.searchTeacher{
  font-size: 25px;
}
.content{
  margin-top: 300px;
}

</style>
</head>
<body>

<div class="content">
<div class="searchTeacher">
   <form class="" method="POST">
		
        <div id="search">
          <input type="text" name="id_search"  placeholder="Enter id" value="" class="search" style="height:30px;width:60%;margin-top:10px;font-size: 25px;">
          <button name="searchById" class="searchBtn" >search by id</button>
            </div>
      </form>
           
            <br><br>
           
             
             <br><br>
    
                 <table  class="mytable"  >
                     <thead style="text-align: center;">
                            <tr>
                             <td><b> ID</b></td>
                            <td><b>Name</b></td>
                            <td><b>Last Name</b></td>
                            <td><b>Mobile</b></td>
                            <td><b>Qualification</b></td>
                            <td><b>Assigned Course</b></td>
                            <td><b>Semester</b></td>
                            <td><b>Year</b></td>
                            </tr>
                     </thead>
                          <tbody>
                              <?php 
                         
                         if (isset($_POST['searchById'])) {
                         
                            $id=$_POST['id_search'];
                            $result=mysqli_query($conn,"SELECT * FROM teacher WHERE Tid= $id " );

                            if(mysqli_num_rows($result)>0){
                              while($row = mysqli_fetch_array($result)){
                             
                                echo "<tr>";
                                      
                                      echo "<td>" . $row['Tid'] . "</td>";
                                      echo "<td>" . $row['Name'] . "</td>";
                                      echo "<td>" . $row['Fname'] . "</td>";
                                      echo "<td>" . $row['mobile'] . "</td>";
                                      echo "<td>" . $row['Qualification'] . "</td>";
                                      echo "<td>" . $row['Course'] . "</td>";
                                      echo "<td>" . $row['Semester'] . "</td>";
                                      echo "<td>" . $row['Year'] . "</td>";
                                      
                                   echo "</tr>";
                              }
                            }else{
                              echo "<tr>". "<h4>No records found for this id</h4>".  " </tr>";
                            }
                          
                             
                         
                            }


                              ?>
                         
                          </tbody>
               
                        <br><br>
                 </table>

              
                 </div>
                 <?php include_once("../footer/Footer.php"); ?>
</div>    


</body>
</html>
