<?php
require_once('../database/db.php');
require_once('../Header/Header.php');
include_once("../security/session.php");
// include_once('SideBar.php');
$id=0;
$count=0;
$tid='';$tname;$tfname='' ; $tmobile='';$qualify='';$assign='' ; $year='';$semester='';
if(isset($_POST['save'])){
$tid=$_POST['teacherId'];
$tname=$_POST['teacherName'];
$tfname=$_POST['teacherFatherName'];
$tmobile=$_POST['teachermobile'];
$qualify=$_POST['qualify'];
$assign=$_POST['assign'];
$year=$_POST['year'];
$semester=$_POST['semester'];

$sql=mysqli_query($conn,"INSERT INTO teacher(Tid,Name,Fname,mobile,Qualification,Course,Year,Semester)  values ('$tid','$tname','$tfname','$tmobile','$qualify','$assign','$year','$semester')  ") or  die("data insert error");
}
$tname='';$tfname='' ; $tmobile='';$degree='';$assign='' ; $year='';$semester='';
$result=mysqli_query($conn,'SELECT * FROM teacher');
while(mysqli_fetch_array($result)){
  $count++;
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Teacher Registration</title>
    <style>
     
.Teacher
{
         padding-left: 200px;
            border: 10px solid gray;
            width: 40%;
            height: 50%;
            margin-left: 400px;
            margin-bottom: 0px;
            margin-top: 0px;
            font-size: 30px;
            font-weight: bold;
            background-color: darkgrey;
            border-radius: 60px;
            
}
.viewTeacher{
  font-size: 20px;
  padding: 20px;
  margin: 10px;
  background-color: gainsboro;
}
.regBtn{
  padding: 20px;
  font-size: 20px;
  background-color: gainsboro;
}

body{
  background-color: white;
}
.content{
  margin-top: 200px;
}
.error{
  color: crimson;
}
    </style>
</head>
<body>
  
    <form action="#" method="POST">
       
    <br><br>
    <div class="content">

   
    
    <div class="Teacher">
               <h4> Teacher Registration Form</h4>
               <p><span class="error">* required field</span></p>

             <input type="hidden"  name="hid" value="$_POST['hid']"><br><br>
           ID.No <input type="text" placeholder="Enter Teacher ID.No"   name="teacherId"  
            style="height:30px;margin-left:150px;width:40%;margin-top:10px;font-size: 23px" required   value="<?php echo $tname;     ?>"><span class="error">* </span><br><br>
           First Name <input type="text" placeholder="Enter Teacher Name"     name="teacherName"  
            style="height:30px;margin-left:90px;width:40%;margin-top:10px;font-size: 23px" required   value="<?php echo $tname;     ?>"><span class="error">* </span><br><br>
           Last Name <input type="text" placeholder="Enter Father Name"     name="teacherFatherName" 
             style="height:30px;margin-left:95px;width:40%;margin-top:10px;font-size: 23px" required   value="<?php echo $tfname;     ?>"><span class="error">* </span><br><br>
           Mobile <input type="number" placeholder="Enter phone number"   name="teachermobile" 
            style="height:30px;margin-left:140px;width:40%;margin-top:10px;font-size: 23px" required  value="<?php echo $tmobile;     ?>"><span class="error">* </span><br><br>
                    <br><br>
          <b>Acaddemic qualification & specialization:</b><br><br>
          
              <input type="radio" name="qualify" value="Degree" style="font-size: 20px"><b>Degree</b>
              <input type="radio" name="qualify" value="Master" style="font-size: 23px"><b>Master</b>
              <input type="radio" name="qualify" value="PHD" style="font-size: 23px"><b>PHD</b>&nbsp;&nbsp;&nbsp;<span class="error">* </span>
            
              <div>
           Year:<input type="number" max="5" min="1" name="year" value=""
            style="height:30px;margin-left:150px;width:40%;margin-top:10px;margin-left:150px;font-size: 23px" required placeholder="Enter Year"><span class="error">* </span><br><br>
           Semester:<input type="number" max="2" min="1" name="semester" placeholder="Enter semester" value=""
            style="height:30px;margin-left:100px;width:40%;margin-top:10px;font-size: 23px" required><span class="error">* </span><br><br>
           Assign Course :<input type="text" value="" name="assign" placeholder="Enter assigning course" 
           style="height:30px;margin-left:30px;width:40%;margin-top:10px;font-size: 23px" required><span class="error">* </span>
                                       </div>
                     <br><br>
                      <input type="submit" value="Register" class="regBtn" name="save">


                      <button name ="views" value="" class="viewTeacher" onclick="window.location.href='ViewTeacher.php ' " >ViewTeacher </button> 
                    </form>

           </div>
    </div>
        
            <?php include("../footer/Footer.php"); ?>
</body>
</html>