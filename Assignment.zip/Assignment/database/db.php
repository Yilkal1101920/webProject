<?php 
$conn=mysqli_connect("localhost","root","","cms");
// print("connected");
if($conn ==false){
    die("ERROR: Could not connect. " . mysqli_connect_error());
}

?>